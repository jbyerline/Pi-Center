package com.jbyerline.stats

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class StatsApplication {

	static void main(String[] args) {
		SpringApplication.run(StatsApplication, args)
	}

}
